# React beadandó

Ez az egyoldalas React alkalmazás két aloldalt tartalmaz:

## 🎨 Color Picker
- HTML input segítségével választunk színt.
- A kiválasztott színt élőben mutatja.

## ⏱ Timer
- Egyszerű stopperóra.
- Start / Pause / Reset gomb.
- `useState`, `useEffect` használatával.

## Technológiák
- React 19
- Vite build rendszer (Babel nélkül)
